# cloud_app.py - RENDER VERSION
import os
import logging
from datetime import datetime
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
import psycopg2
from psycopg2 import pool
from dotenv import load_dotenv

load_dotenv()

# Initialize Flask
app = Flask(__name__)
CORS(app, origins="*")

# Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ✅ RENDER FIX: Get DATABASE_URL directly
DATABASE_URL = os.getenv('DATABASE_URL')

if DATABASE_URL:
    # Parse Render's DATABASE_URL
    from urllib.parse import urlparse
    url = urlparse(DATABASE_URL)
    
    # Database Pool using parsed URL
    db_pool = psycopg2.pool.SimpleConnectionPool(
        1, 10,
        user=url.username,
        password=url.password,
        host=url.hostname,
        port=url.port or 5432,
        database=url.path[1:]  # Remove leading /
    )
else:
    # Fallback to individual env vars
    db_pool = psycopg2.pool.SimpleConnectionPool(
        1, 10,
        user=os.getenv("PGUSER"),
        password=os.getenv("PGPASSWORD"),
        host=os.getenv("PGHOST"),
        port=os.getenv("PGPORT", "5432"),
        database=os.getenv("PGDATABASE")
    )

def get_db():
    return db_pool.getconn()

def release_db(conn):
    db_pool.putconn(conn)

# ============================================
# PUBLIC ROUTES
# ============================================

@app.route('/')
def index():
    """Homepage - redirect to report form"""
    return render_template('report_outage.html')

@app.route('/report')
def report_form():
    """Public outage report form"""
    return render_template('report_outage.html')

@app.route('/api/submit_power_outage', methods=['POST'])
def submit_power_outage():
    """Submit power outage report - PUBLIC API"""
    try:
        data = request.get_json()
        
        # Extract data
        full_name = data.get('full_name', '').strip()
        contact_number = data.get('contact_number', '').strip()
        email = data.get('email', '').strip()
        address = data.get('address', '').strip()
        latitude = data.get('latitude')
        longitude = data.get('longitude')
        details = data.get('details', '').strip()
        incident_type = data.get('incident_type', 'power_outage')
        
        # Validate
        if not all([full_name, contact_number, address, details, latitude, longitude]):
            return jsonify({'success': False, 'error': 'Missing required fields'}), 400
        
        # Determine priority
        critical_types = ['fallen_wire', 'fire_hazard', 'transformer_issue']
        priority = 'CRITICAL' if incident_type in critical_types else 'HIGH'
        
        # Insert to database
        conn = get_db()
        cur = conn.cursor()
        
        cur.execute("""
            INSERT INTO power_outage_reports 
            (full_name, contact_number, email, address, latitude, longitude, 
             details, incident_type_detail, priority, status, source, timestamp)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
            RETURNING report_id
        """, (full_name, contact_number, email, address, latitude, longitude,
              details, incident_type, priority, 'NEW', 'Web Form'))
        
        report_id = cur.fetchone()[0]
        conn.commit()
        
        cur.close()
        release_db(conn)
        
        logger.info(f"✅ Report {report_id} submitted from web form")
        
        return jsonify({
            'success': True,
            'report_id': report_id,
            'priority': priority,
            'message': 'Report submitted successfully'
        })
        
    except Exception as e:
        logger.error(f"Error submitting report: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================
# API ENDPOINTS FOR LOCAL DASHBOARD
# ============================================

@app.route('/api/complaints', methods=['GET'])
def get_complaints_api():
    """Get all complaints - FOR LOCAL DASHBOARD"""
    try:
        conn = get_db()
        cur = conn.cursor()
        
        # Get filters from query params
        status = request.args.get('status', 'All Status')
        priority = request.args.get('priority', 'All Priorities')
        
        query = """
            SELECT report_id, full_name, contact_number, address, 
                   latitude, longitude, details, priority, status, 
                   timestamp, incident_type_detail
            FROM power_outage_reports
            WHERE (hidden = FALSE OR hidden IS NULL)
        """
        params = []
        
        if status != 'All Status':
            query += " AND status = %s"
            params.append(status)
        
        if priority != 'All Priorities':
            query += " AND priority = %s"
            params.append(priority)
        
        query += " ORDER BY timestamp DESC LIMIT 100"
        
        cur.execute(query, params)
        rows = cur.fetchall()
        
        complaints = []
        for row in rows:
            complaints.append({
                'report_id': row[0],
                'customer_name': row[1],
                'contact': row[2],
                'address': row[3],
                'latitude': row[4],
                'longitude': row[5],
                'description': row[6],
                'priority': row[7],
                'status': row[8],
                'timestamp': row[9].isoformat() if row[9] else None,
                'incident_type': row[10]
            })
        
        cur.close()
        release_db(conn)
        
        return jsonify({
            'success': True,
            'complaints': complaints,
            'count': len(complaints)
        })
        
    except Exception as e:
        logger.error(f"Error fetching complaints: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/update_status/<int:report_id>', methods=['POST'])
def update_status_api(report_id):
    """Update complaint status - FOR LOCAL DASHBOARD"""
    try:
        data = request.get_json()
        new_status = data.get('status', '').upper()
        
        if new_status not in ['NEW', 'ASSIGNED', 'IN_PROGRESS', 'RESOLVED']:
            return jsonify({'success': False, 'error': 'Invalid status'}), 400
        
        conn = get_db()
        cur = conn.cursor()
        
        cur.execute("""
            UPDATE power_outage_reports 
            SET status = %s 
            WHERE report_id = %s
        """, (new_status, report_id))
        
        conn.commit()
        cur.close()
        release_db(conn)
        
        logger.info(f"✅ Report {report_id} status updated to {new_status}")
        
        return jsonify({
            'success': True,
            'message': f'Status updated to {new_status}'
        })
        
    except Exception as e:
        logger.error(f"Error updating status: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500

# ============================================
# FACEBOOK MESSENGER WEBHOOK
# ============================================

VERIFY_TOKEN = os.getenv('FB_VERIFY_TOKEN', 'your_secret_verify_token_12345')
PAGE_ACCESS_TOKEN = os.getenv('FB_PAGE_ACCESS_TOKEN')

@app.route('/webhook', methods=['GET'])
def verify_webhook():
    """Verify Facebook webhook"""
    mode = request.args.get('hub.mode')
    token = request.args.get('hub.verify_token')
    challenge = request.args.get('hub.challenge')
    
    if mode == 'subscribe' and token == VERIFY_TOKEN:
        logger.info('✅ Webhook verified')
        return challenge, 200
    else:
        logger.error('❌ Webhook verification failed')
        return 'Forbidden', 403

@app.route('/webhook', methods=['POST'])
def webhook_handler():
    """Handle Facebook Messenger messages"""
    try:
        data = request.get_json()
        
        if data.get('object') == 'page':
            for entry in data.get('entry', []):
                for messaging_event in entry.get('messaging', []):
                    sender_id = messaging_event['sender']['id']
                    
                    if messaging_event.get('message'):
                        message_text = messaging_event['message'].get('text', '')
                        
                        if 'power' in message_text.lower() or 'outage' in message_text.lower():
                            conn = get_db()
                            cur = conn.cursor()
                            
                            cur.execute("""
                                INSERT INTO power_outage_reports 
                                (full_name, contact_number, address, details, 
                                 priority, status, source, timestamp)
                                VALUES (%s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP)
                                RETURNING report_id
                            """, (f'FB User {sender_id}', sender_id, 'Via Messenger', 
                                  message_text, 'HIGH', 'NEW', 'Facebook Messenger'))
                            
                            report_id = cur.fetchone()[0]
                            conn.commit()
                            cur.close()
                            release_db(conn)
                            
                            logger.info(f"✅ FB Report {report_id} from {sender_id}")
                            
                            send_fb_message(sender_id, 
                                f"✅ Your report has been received! Reference: PO-{report_id:06d}")
        
        return 'OK', 200
        
    except Exception as e:
        logger.error(f"Webhook error: {e}")
        return 'OK', 200

def send_fb_message(recipient_id, message_text):
    """Send message via Facebook Messenger"""
    import requests
    
    if not PAGE_ACCESS_TOKEN:
        logger.warning("FB_PAGE_ACCESS_TOKEN not set")
        return
    
    url = f"https://graph.facebook.com/v18.0/me/messages?access_token={PAGE_ACCESS_TOKEN}"
    
    payload = {
        'recipient': {'id': recipient_id},
        'message': {'text': message_text}
    }
    
    response = requests.post(url, json=payload)
    
    if response.status_code == 200:
        logger.info(f"✅ Message sent to {recipient_id}")
    else:
        logger.error(f"❌ Failed to send message: {response.text}")

# Health check
@app.route('/health')
def health():
    return jsonify({'status': 'healthy', 'timestamp': datetime.now().isoformat()})

# ✅ RENDER FIX: Production startup
if __name__ == '__main__':
    port = int(os.getenv('PORT', 10000))
    app.run(host='0.0.0.0', port=port, debug=False)